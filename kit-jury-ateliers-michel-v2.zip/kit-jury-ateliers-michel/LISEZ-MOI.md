# Agent de pré-devis — Les Ateliers Michel · Kit d'installation

**Ouvrez `1-INSTALLER.html` dans votre navigateur (double-clic) et suivez la page.** Tout se fait dans cette page : aucune commande, aucun code.

Durée : environ 30 minutes, dont 15 pour créer les comptes gratuits (n8n, Google AI Studio, OpenRouteService, Airtable, PDF.co).

## Contenu

| Fichier | À quoi il sert |
|---|---|
| `1-INSTALLER.html` | Guide pas à pas. Vous collez vos liens, il fabrique votre workflow n8n prêt à importer. |
| `releve-chantier.html` | Le formulaire du commercial sur le terrain (téléphone ou ordinateur). |
| `envoyer-dossier.html` | Envoie un dossier de démonstration tout prêt (2 scénarios), pour tester sans rien saisir. |
| `donnees/referentiels-ateliers-michel.xlsx` | Grille fournisseurs, règles RGE / TVA / majorations, accords-cadres, à déposer dans votre Google Drive. |

## Ce que vous allez tester

1. Un relevé de chantier est envoyé à l'agent.
2. L'agent fait **un seul appel à l'IA** pour comprendre les notes, puis calcule prix, heures, trajet et TVA **par du code lisible** (pas par l'IA).
3. Vous recevez la fiche par e-mail : vous la **validez, corrigez ou rejetez**.
4. Une fois validée, le devis est pré-rempli dans Airtable ; vous complétez le QCM et cliquez sur **▶ Générer le devis**.
5. Vous obtenez un PDF de 3 pages et un **brouillon** d'e-mail au client. L'agent n'envoie jamais rien au client lui-même.

Toutes les données sont fictives.

## Si quelque chose ne marche pas

| Symptôme | Solution |
|---|---|
| L'envoi du relevé échoue | Le workflow n'est pas publié dans n8n (bouton **Publish**), ou l'adresse n8n saisie est incomplète. |
| « Trajet non calculé » dans la fiche | Connexion Header Auth : *Name* doit être exactement `Authorization`, *Value* votre clé OpenRouteService. Vous pouvez aussi saisir le trajet au moment de valider. |
| « Réponse de l'IA illisible » | Clé Gemini invalide ou quota gratuit momentanément dépassé : réessayez une minute plus tard. |
| Produits « Non trouvé dans la grille » | Les onglets du Google Sheet ont été renommés. Ils doivent rester `Grille_Tarifs_Fournisseurs`, `Regles_RGE_2026` et `Accords_Fournisseurs`. |
| « ▶ Générer le devis » ne fait rien | La formule du champ n'a pas été remplacée dans Airtable (dernière étape de la page d'installation). |
| Erreur à l'impression du PDF | Clé PDF.co manquante, ou nœud PDF.co non installé dans n8n. |
